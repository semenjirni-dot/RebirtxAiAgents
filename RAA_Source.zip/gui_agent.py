import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox


PROMPTS = {
    "RU": """Ты — автономный ИИ-агент с полным доступом к Windows через Python-скрипты.
Пользователь дает тебе задачи на русском языке. Ты должен писать законченный Python-код для их выполнения.
ПРАВИЛА:
1. Выдавай ТОЛЬКО чистый код Python. Никакого текста, объяснений и markdown-разметки (НЕ пиши ```python).
2. ВАЖНО: ВСЕГДА начинай свой код с импорта всех необходимых библиотек. На компьютере уже установлены и ДОСТУПНЫ для использования: os, sys, subprocess, platform, time, shutil, psutil. Обязательно пиши строки import для тех из них, которые нужны в коде!
3. Учитывай историю чата! Если код упал с ошибкой, перепиши его, исправив баг.""",

    "EN": """You are an autonomous AI agent with full access to Windows via Python scripts.
The user gives you tasks in English. You must write complete Python code to execute them.
RULES:
1. Output ONLY clean Python code. No text, no explanations, no markdown formatting (DO NOT write ```python).
2. IMPORTANT: ALWAYS start your code by importing all necessary libraries. The following are already installed and AVAILABLE: os, sys, subprocess, platform, time, shutil, psutil. Make sure to write import lines for those needed in the code!
3. Consider the chat history! If the code crashes with an error, rewrite it and fix the bug."""
}

LANG_TEXTS = {
    "RU": {
        "title": "Universal Local AI Agent (Ollama)", "model": "Модель Ollama:", "chat": "Выбор чата:",
        "new_chat": "+ Новый", "ready": "🤖 Агент готов к работе", "thinking": "🧠 ИИ ({}) думает...",
        "waiting": "⚠️ Ожидание подтверждения выполнения...", "executing": "⚡ Выполнение скрипта...",
        "done": "🤖 Готов к новой задаче", "error": "❌ Ошибка выполнения", "btn_send": "Отправить",
        "sys_wait": "Система: Ожидание вашей команды...\n", "chat_name": "Чат",
        "new_chat_msg": "Система: Ожидание команды в {}...\n",
        "confirm_title": "Подтверждение действия",
        "confirm_msg": "ИИ сгенерировал код для выполнения задачи.\n\nЗапустить его на вашем компьютере?",
        "success_msg": "✅ Успешно выполнено!", "output_msg": "Вывод программы:\n",
        "crash_msg": "❌ Скрипт упал с ошибкой:\n",
        "fix_msg": "Твой код упал с ошибкой:\n{}\nИсправь его при следующем запросе.",
        "err_model": "❌ Ошибка: Поле названия модели не должно быть пустым!",
        "err_ollama": "💥 Ошибка Ollama или скрипта: ",
        "cancelled": "🚫 Отменено пользователем.",
        "menu_copy": "Копировать", "menu_paste": "Вставить", "menu_cut": "Вырезать",
        "menu_select_all": "Выделить всё"
    },
    "EN": {
        "title": "Universal Local AI Agent (Ollama)", "model": "Ollama Model:", "chat": "Select Chat:",
        "new_chat": "+ New", "ready": "🤖 Agent is ready", "thinking": "🧠 AI ({}) is thinking...",
        "waiting": "⚠️ Waiting for execution confirmation...", "executing": "⚡ Executing script...",
        "done": "🤖 Ready for the next task", "error": "❌ Execution error", "btn_send": "Send",
        "sys_wait": "System: Waiting for your command...\n", "chat_name": "Chat",
        "new_chat_msg": "System: Waiting for command in {}...\n",
        "confirm_title": "Confirm Action",
        "confirm_msg": "AI generated code to execute the task.\n\nRun it on your computer?",
        "success_msg": "✅ Executed successfully!", "output_msg": "Program output:\n",
        "crash_msg": "❌ Script crashed with error:\n",
        "fix_msg": "Your code crashed with error:\n{}\nFix it in the next request.",
        "err_model": "❌ Error: Model name field cannot be empty!",
        "err_ollama": "💥 Ollama or script error: ",
        "cancelled": "🚫 Cancelled by user.",
        "menu_copy": "Copy", "menu_paste": "Paste", "menu_cut": "Cut",
        "menu_select_all": "Select All"
    }
}


class AIAgentApp:
    def __init__(self, root):
        self.root = root
        self.lang = "RU"
        self.t = LANG_TEXTS[self.lang]

        self.root.title(self.t["title"])
        self.root.geometry("800x680")
        self.root.configure(bg="#1e1e1e")

        self.chats = {
            f"{self.t['chat_name']} 1": {
                "history": [{'role': 'system', 'content': PROMPTS[self.lang]}],
                "log": self.t["sys_wait"] + "-" * 60 + "\n"
            }
        }
        self.current_chat = f"{self.t['chat_name']} 1"

        # ---------------- ВЕРХНЯЯ ПАНЕЛЬ ----------------
        self.top_frame = tk.Frame(root, bg="#1e1e1e")
        self.top_frame.pack(fill=tk.X, padx=15, pady=10)

        self.model_label = tk.Label(self.top_frame, text=self.t["model"], fg="#ffffff",
                                    bg="#1e1e1e", font=("Arial", 10, "bold"))
        self.model_label.pack(side=tk.LEFT, padx=5)

        self.model_entry = tk.Entry(self.top_frame, bg="#2d2d2d", fg="#ffffff",
                                    insertbackground="white", font=("Arial", 10), width=15)
        self.model_entry.pack(side=tk.LEFT, padx=5)
        self.model_entry.insert(0, "qwen2.5:7b")

        self.lang_btn = tk.Button(self.top_frame, text="🌐 EN", command=self.toggle_language,
                                  bg="#2d2d2d", fg="#ffffff", font=("Arial", 9, "bold"),
                                  relief=tk.FLAT, padx=10)
        self.lang_btn.pack(side=tk.LEFT, padx=20)

        self.chat_frame = tk.Frame(self.top_frame, bg="#1e1e1e")
        self.chat_frame.pack(side=tk.RIGHT, padx=5)

        self.chat_label = tk.Label(self.chat_frame, text=self.t["chat"], fg="#ffffff",
                                   bg="#1e1e1e", font=("Arial", 10, "bold"))
        self.chat_label.pack(side=tk.LEFT, padx=2)

        self.chat_var = tk.StringVar(root)
        self.chat_var.set(self.current_chat)

        self.chat_menu = tk.OptionMenu(self.chat_frame, self.chat_var,
                                       *list(self.chats.keys()), command=self.switch_chat)
        self.chat_menu.config(bg="#2d2d2d", fg="#ffffff", activebackground="#0e639c",
                              activeforeground="#ffffff", relief=tk.FLAT, font=("Arial", 9))
        self.chat_menu["menu"].config(bg="#2d2d2d", fg="#ffffff")
        self.chat_menu.pack(side=tk.LEFT, padx=5)

        self.new_chat_btn = tk.Button(self.chat_frame, text=self.t["new_chat"],
                                      command=self.create_new_chat, bg="#2d2d2d", fg="#ffffff",
                                      font=("Arial", 9, "bold"), relief=tk.FLAT, padx=5)
        self.new_chat_btn.pack(side=tk.LEFT, padx=2)

        # ---------------- СТРОКА СТАТУСА ----------------
        self.status_label = tk.Label(root, text=self.t["ready"], fg="#4caf50",
                                     bg="#1e1e1e", font=("Arial", 11, "bold"))
        self.status_label.pack(pady=5)

        # ---------------- ОКНО ЛОГОВ ----------------
        self.log_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=90, height=22,
                                                  bg="#252526", fg="#d4d4d4",
                                                  font=("Consolas", 10))
        self.log_area.pack(padx=15, pady=5)
        self.refresh_log_display()

        # ---------------- ПОЛЕ ВВОДА ----------------
        self.input_frame = tk.Frame(root, bg="#1e1e1e")
        self.input_frame.pack(fill=tk.X, padx=15, pady=10)

        self.user_entry = tk.Entry(self.input_frame, bg="#2d2d2d", fg="#ffffff",
                                   insertbackground="white", font=("Arial", 11), width=65)
        self.user_entry.pack(side=tk.LEFT, padx=5, ipady=4, fill=tk.X, expand=True)
        self.user_entry.bind("<Return>", lambda e: self.start_agent_thread())

        self.send_btn = tk.Button(self.input_frame, text=self.t["btn_send"],
                                  command=self.start_agent_thread, bg="#0e639c", fg="white",
                                  font=("Arial", 10, "bold"), relief=tk.FLAT, padx=15)
        self.send_btn.pack(side=tk.RIGHT, padx=5)

        self._ctx_widget = self.user_entry
        self.setup_menu_and_keys()

    # ---------- ЯЗЫК ----------
    def toggle_language(self):
        self.lang = "EN" if self.lang == "RU" else "RU"
        self.t = LANG_TEXTS[self.lang]

        self.lang_btn.config(text="🌐 RU" if self.lang == "EN" else "🌐 EN")
        self.model_label.config(text=self.t["model"])
        self.chat_label.config(text=self.t["chat"])
        self.new_chat_btn.config(text=self.t["new_chat"])
        self.send_btn.config(text=self.t["btn_send"])

        cur = self.status_label.cget("text").lower()
        if "готов" in cur or "ready" in cur:
            self.status_label.config(text=self.t["ready"])

        if len(self.chats[self.current_chat]["history"]) == 1:
            self.chats[self.current_chat]["history"][0]["content"] = PROMPTS[self.lang]

        self.log(f"ℹ️ Language changed to {self.lang}")

    # ---------- ЛОГ ----------
    def log(self, text):
        self.log_area.configure(state='normal')
        self.log_area.insert(tk.END, text + "\n")
        self.log_area.see(tk.END)
        self.log_area.configure(state='disabled')
        self.chats[self.current_chat]["log"] = self.log_area.get("1.0", tk.END)

    def refresh_log_display(self):
        self.log_area.configure(state='normal')
        self.log_area.delete("1.0", tk.END)
        self.log_area.insert(tk.END, self.chats[self.current_chat]["log"])
        self.log_area.configure(state='disabled')

    # ---------- ЧАТЫ ----------
    def create_new_chat(self):
        name = f"{self.t['chat_name']} {len(self.chats) + 1}"
        self.chats[name] = {
            "history": [{'role': 'system', 'content': PROMPTS[self.lang]}],
            "log": self.t["new_chat_msg"].format(name) + "-" * 60 + "\n"
        }

        self.chat_menu['menu'].delete(0, 'end')
        for chat_name in self.chats.keys():
            self.chat_menu['menu'].add_command(
                label=chat_name,
                command=tk._setit(self.chat_var, chat_name, self.switch_chat)
            )

        self.chat_var.set(name)
        self.current_chat = name
        self.refresh_log_display()

    def switch_chat(self, chat_name):
        self.current_chat = self.chat_var.get()
        self.refresh_log_display()

    # ---------- ОСНОВНАЯ ЛОГИКА ----------
    def start_agent_thread(self):
        task = self.user_entry.get().strip()
        if task:
            self.user_entry.delete(0, tk.END)
            threading.Thread(target=self.process_task, args=(task,), daemon=True).start()

    def _ask_confirm(self):
        """Спрашивает подтверждение в главном потоке, ждёт ответ из фонового."""
        event = threading.Event()
        result = {"ok": False}

        def ask():
            try:
                result["ok"] = messagebox.askyesno(
                    self.t["confirm_title"], self.t["confirm_msg"]
                )
            finally:
                event.set()

        self.root.after(0, ask)
        event.wait()
        return result["ok"]

    def process_task(self, user_task):
        try:
            import ollama
        except ImportError:
            self.log("💥 Модуль 'ollama' не установлен. Выполните: pip install ollama")
            self.status_label.config(text="💥 Error", fg="#f44336")
            return

        model = self.model_entry.get().strip()
        if not model:
            self.log(self.t["err_model"])
            return

        self.log(f"\n{self.lang}: {user_task}")
        self.status_label.config(text=self.t["thinking"].format(model), fg="#ffb74d")
        self.chats[self.current_chat]["history"].append({'role': 'user', 'content': user_task})

        try:
            response = ollama.chat(
                model=model,
                messages=self.chats[self.current_chat]["history"],
                options={'temperature': 0.1}
            )

            if hasattr(response, 'message') and hasattr(response.message, 'content'):
                script_code = response.message.content
            elif isinstance(response, dict) and 'message' in response:
                script_code = response['message']['content']
            else:
                script_code = str(response)

            # Очищаем только markdown-обёртки, не ломая валидный код
            script_code = script_code.strip()
            if script_code.startswith("```"):
                lines = script_code.splitlines()
                if lines and lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]
                script_code = "\n".join(lines).strip()

            self.chats[self.current_chat]["history"].append(
                {'role': 'assistant', 'content': script_code}
            )
            self.log(f"⚙️ Code:\n{'-' * 40}\n{script_code}\n{'-' * 40}")
            self.status_label.config(text=self.t["waiting"], fg="#f44336")

            if not self._ask_confirm():
                self.log(self.t["cancelled"])
                self.status_label.config(text=self.t["done"], fg="#4caf50")
                return

            self.status_label.config(text=self.t["executing"], fg="#2196f3")
            temp_file = "temp_gui_script.py"
            with open(temp_file, "w", encoding="utf-8") as f:
                f.write(script_code)
            try:
                result = subprocess.run(
                    [sys.executable, temp_file],
                    text=True, capture_output=True, encoding='utf-8'
                )
            finally:
                if os.path.exists(temp_file):
                    os.remove(temp_file)

            if result.returncode == 0:
                self.log(self.t["success_msg"])
                if result.stdout:
                    self.log(f"{self.t['output_msg']}{result.stdout}")
                self.status_label.config(text=self.t["done"], fg="#4caf50")
            else:
                self.log(f"{self.t['crash_msg']}{result.stderr}")
                self.status_label.config(text=self.t["error"], fg="#f44336")
                self.chats[self.current_chat]["history"].append(
                    {'role': 'user', 'content': self.t["fix_msg"].format(result.stderr)}
                )

        except Exception as e:
            self.log(f"{self.t['err_ollama']}{e}")
            self.status_label.config(text="💥 Error", fg="#f44336")

    # ---------- МЕНЮ И ГОРЯЧИЕ КЛАВИШИ ----------
    def setup_menu_and_keys(self):
        m = tk.Menu(self.root, tearoff=0, bg="#2d2d2d", fg="#ffffff",
                    activebackground="#0e639c", activeforeground="#ffffff")

        def do_copy():
            self._ctx_widget.event_generate("<<Copy>>")
        def do_paste():
            self._ctx_widget.event_generate("<<Paste>>")
        def do_cut():
            self._ctx_widget.event_generate("<<Cut>>")
        def do_select_all():
            w = self._ctx_widget
            if isinstance(w, tk.Entry):
                w.select_range(0, tk.END)
            else:
                w.tag_add("sel", "1.0", tk.END)
                w.mark_set(tk.INSERT, "1.0")
                w.see(tk.INSERT)

        m.add_command(label=self.t["menu_copy"], command=do_copy)
        m.add_command(label=self.t["menu_paste"], command=do_paste)
        m.add_command(label=self.t["menu_cut"], command=do_cut)
        m.add_separator()
        m.add_command(label=self.t["menu_select_all"], command=do_select_all)

        def show(e):
            self._ctx_widget = e.widget
            state = "disabled" if self._ctx_widget == self.log_area else "normal"
            m.entryconfigure(self.t["menu_paste"], state=state)
            m.entryconfigure(self.t["menu_cut"], state=state)
            try:
                m.tk_popup(e.x_root, e.y_root)
            finally:
                m.grab_release()

        keymap = {
            'c': "<<Copy>>", 'C': "<<Copy>>",
            'v': "<<Paste>>", 'V': "<<Paste>>",
            'x': "<<Cut>>", 'X': "<<Cut>>",
            'a': "<<SelectAll>>", 'A': "<<SelectAll>>",
        }

        def make_handler(event_name):
            def handler(e):
                e.widget.event_generate(event_name)
                return "break"
            return handler

        for w in (self.log_area, self.user_entry):
            w.bind("<Button-3>", show)
            for key, event_name in keymap.items():
                w.bind(f"<Control-KeyPress-{key}>", make_handler(event_name))


if __name__ == "__main__":
    root = tk.Tk()
    app = AIAgentApp(root)
    root.mainloop()